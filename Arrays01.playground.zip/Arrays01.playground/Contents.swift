import UIKit

var greeting = "Hello, playground"

var numbers:[Int] = [1, 2, 3]
print(numbers)

var emptyArray = [Int]()
print(emptyArray)

var programmingLanguages = ["Swift", "Python", "Java"]
print(programmingLanguages[0])
programmingLanguages[0] = "JavaScript"
print(programmingLanguages[0])

var names:[String] = ["Kishore", "Sohi", "Bala", "Ram"]
names.append("Subhani")
print(names)
names.insert("Gayathri", at: 2)
print(names)
print(names.count)
names.sort()
print(names)
names.reverse()
print(names)
names.remove(at:4)
print(names)
names.swapAt(2,3)
print(names)
var oddNumbers = [1,3,5,7]
var evenNumbers = [2,4,6,8]
oddNumbers.append(contentsOf: evenNumbers)
print(oddNumbers)


var capitals = ["Andhra Pradesh":"Amaravathi", "Telangana":"Hyderabad", "Tamilnadu":"Chennai"]
print(capitals)
print(capitals.count)
var numbers1 = [1:"One",2:"two",3:"Three"]
print(numbers1)
numbers1[4] = "Four"
print(numbers1)
var courses = [44560:"ADB", 44460:"DB", 44542:"Java"]
print(courses)
courses[44560] = "Python"
print(courses)
courses.removeValue(forKey:44460)
print(courses)
for (key,values) in courses{
    print(key)
}
for(key, values ) in courses{
print(values)
}
for (key,values) in courses
{
print("\(key) : \(values)")
}


var letters = Set<Character>()
print("letters is of type Set<Character> with \(letters.count) items.")

letters.insert("a")
print(letters)
print("letters is of type Set<Character> with \(letters.count) items.")
letters = []
print("letters is of type Set<Character> with \(letters.count) items.")
var favoriteGenres: Set<String> = ["Rock", "Classical", "Hip hop"]
print(favoriteGenres)
var players: Set<String> = ["Ronaldo", "Messi", "Kohli"]
print(players)
print(players.count)
print(players.contains("Steve Smith"))
players.insert("Maxwell")
print(players)
players.remove("David Warner")
print(players)
