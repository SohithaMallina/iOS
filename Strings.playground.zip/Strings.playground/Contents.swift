import UIKit

var greeting = "Hello, playground"
var fact = "Northwest Missouri State University"
fact[fact.index(fact.endIndex,offsetBy: -7)]
var food = "Mangoes, Bananas, Muskmelon, Watermelon."
food[food.startIndex..<food.index(food.endIndex,offsetBy: -5)]
var course = "44643-Mobile Computing-iOS"
course[course.startIndex..<course.index(course.startIndex,offsetBy: 5)]
